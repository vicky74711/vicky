<?php

/*configs By HACK-TO-WIN*/


$user_agent ="xxxxxxxxxxxx";

//cookie
$PHPSESSID ='xxxxxxxxxxxx';

//account id
$accountId ='xxxx';


$accessToken ='xxxxxxxxxxxx';

//username
$user ='xxxx';

//devive name
$dev_man ='xxxx';

//divice modile
$dev_name ='xxxxxxx';






